
	var characters = {};
	var characterGenders = {};

	function drawGenderSplit () {

		var data = [];
		$(".gender-option").each((i, option) => { 
			var charName = $(option).data("character-name");

			var lineIndexes = characters[charName].lineIndex;
			var charGender = $(option).val();

			lineIndexes.forEach((lineIndex) => { 
				if(charGender !== "not-character"){
					data.push({
						name: charName,
						gender: charGender,
						index: lineIndex
					})
				}
			})
		});

		data = data.sort((a, b) => { return a.index - b.index });

		var barWidth = 2;
		var barHeight = 20;

		$("#line-container").empty();
		var linesChart = d3.select("#line-container")
	    .selectAll("div")
	    .data(data.sort())
	    .enter()
	    .append("rect")
	    .style("height", (d) => { return (d.gender === "null"? 2: 1) * barHeight; })
	    .style("width", barWidth)
	    .style("fill", (d) => {

	      if(d.gender === "female"){
	        return "#FF1B84";
	      } else if(d.gender === "male"){
	      	return "#0091E6";
	      } else {
	      	return "BDC3C7";
	      } 

	    })
	    .attr("transform", (d,i) => { 
	    	var top = barHeight;
	    	if(d.gender !== "male"){
	        top = 0;
	      }
	    	return "translate(" + barWidth * i + "," + top + ")"; 
	    });
	    
	}

	function parseText (text) {

		$(".loading-parser").show();
		$("#character-list-container, #display-container").hide();
		var rows = text.split("\n");

	  characters = {};
	  characterGenders = {};

		var currentChar;
	  var isTalking = false;
	  var dialogueIndex = 0;
	  var numLines = 0;
	  var numWords = 0;
	  var rowNumber = -1;

	  var spaceAfterCharName = false;
	  var prevLineWasCharName = false;
	  var prevLineWasSpace = false;

	  var isCommaSeparatedName = false;
		async.series({
	    iterateLines: (cb2) => {

	      async.forEach(rows, (row, cb3) => {

	        rowNumber++;
	        console.log(`${rowNumber}/${rows.length}`)
	        $("#loading-text").text(`Loading ${((rowNumber/rows.length) * 100).toFixed(0)}%`)
	        var numSpaces = 0;

	        //deal with blank line
	        if(row.trim().length === 0){ 
	          //console.log("====================");
	          if(currentChar){
	            // console.log(currentChar)
	            // console.log(numLines)
	            // console.log(isTalking)
	            // console.log("")
	            if(numLines > 0){
	              if(isTalking){
	                characters[currentChar].lineIndex.push(dialogueIndex);
	                characters[currentChar].numberOfLines.push(numLines);
	                characters[currentChar].numberOfWords.push(numWords);
	                characters[currentChar].scriptLineNumber.push(rowNumber);

	                isTalking = false;
	              }
	            } 
	            
	            //isTalking = false;
	          }

	          if (prevLineWasCharName) {
	            spaceAfterCharName = true;
	          }

	          prevLineWasSpace = true;
	          async.setImmediate(() => { cb3(); });
	            
	        //text
	        } else {

	          var isCharacter = false;

	          if(isCommaSeparatedName){ //text seperated with 1 line
	              if(rowNumber > 0){
	                if(rows[rowNumber - 1].trim().length === 0){
	                  row = row.toUpperCase();

	                } else {
	                  if(isCommaSeparatedName) {
	                    if(!row.endsWith(":")){
	                      row = row.toLowerCase();
	                    } else {
	                      row = row.toUpperCase();
	                    }
	                  } 
	                }

	                rows[rowNumber] = row;
	              }
	          }

	          if(row === row.toUpperCase()){
	            isCharacter = true;
	          } else {
	            isCharacter = false;
	          }
	          
	         
	          if(isCharacter) {
	        
	            var charName = row.toUpperCase()
	                              .replace(/\(([^)]+)\)/g, "")
	                              .replace(/\[([^)]+)\]/g, "")
	                              .replace(/[\s]+/g, " ")
	                              .replace(/\"/g, "\'\'")
	                              .replace(/ \' /g, "\'")
	                              .replace(/[\'S ]*[RECORDED ]*[COM ]*VOICE/g, "")
	                              .replace(/[ON|OFF|INTO|FROM] [THE]*[TELEVISION|TV|PHONE|SCREEN|RADIO]+/g, "")
	                              .replace(/[PHONE|RADIO] FILTER/g, "")
	                              .replace(/V[.|\s|\t|/]+[O|0][.|\s|\t|/]*[.]*/g, "")
	                              .replace(/[O|0][.|\s|\t|/]+[S|C][.|\s|\t|/]*[.]*/g, "")
	                              .replace(/P[.|\s|\t]*A[.|\s|\t]*/g, "")
	                              .replace(/CONTINUED/g, "")
	                              .replace(/CONT[\'|’]D/g, "")
	                              .replace(/CONT[.]*/g, "")
	                              .replace(/OVER/g, "")
	                              .replace(/\\/g, "");

	            var povMatch = charName.toUpperCase().match(/[\'S]* P[.]*O[.]*V[.|\s|\b]*/g);
	            var textMatch = charName.toUpperCase().match(/[A-Z]/g);

	            if(isCommaSeparatedName){
	              commaSeparatedCondition = charName.endsWith(":");
	            }

	            charName = charName.replace(/\:/g, "");
	            charName = charName.replace(/[^a-z|A-Z|0-9|\s|\#]*/g, "")
	            charName = charName.replace(/[\s]+/g, " ");

	            var reversed = charName.split("").reverse().join("");
	            var lastWS = reversed.indexOf(reversed.trim().slice(0,1));
	            reversed = reversed.slice(lastWS);
	            charName = reversed.split("").reverse().join("");

	            var firstNonCharIndex = charName.indexOf(charName.trim().slice(0,1));
	            charName = charName.slice(firstNonCharIndex);

	            var commaSeparatedCondition = true;

	            if (!( charName.startsWith("INTERIOR")
	              || charName.startsWith("EXTERIOR")
	              || charName.startsWith("REVISED")
	              || charName.startsWith("FADE IN")
	              || charName.startsWith("FADE OUT")
	              || charName.startsWith("FLASH TO")
	              || charName.startsWith("BACK T")
	              || charName.startsWith("FX ")
	              || charName.startsWith("ANGLE")
	              || charName.startsWith("CLOSE ")
	              || charName.startsWith("THE CAMERA ")
	              || charName.endsWith(" DAY")
	              || charName.endsWith(" NIGHT")
	              || charName.endsWith(" LATER")
	              || charName.endsWith(" SPEAKS")
	              || charName.indexOf("FLASHBACK") !== -1
	              || charName.indexOf("CLOSEUP") !== -1
	              || charName.indexOf("TITLE SEQUENCE") !== -1
	              || charName.indexOf("CONTINUED") !== -1
	              || charName.indexOf("- LATER") !== -1
	              || charName.indexOf("- DAY") !== -1
	              || charName.indexOf("- NIGHT") !== -1
	              || charName.indexOf("CREDITS") !== -1
	              || charName.indexOf("INT ") !== -1
	              || charName.indexOf("EXT ") !== -1
	              || charName.indexOf("ENT ") !== -1
	              || charName.indexOf("INT.") !== -1
	              || charName.indexOf("EXT.") !== -1
	              || charName.indexOf("ENT.") !== -1
	              || charName.indexOf("CLOSE O") !== -1
	              || charName.indexOf("CUT TO") !== -1
	              || charName.indexOf("CLOSE -") !== -1
	              || charName.indexOf("CLOSE UP") !== -1
	              || charName.indexOf("DISSOLVE") !== -1
	              || charName.indexOf("SHOT") !== -1
	              || charName.indexOf("ANGLE ON") !== -1
	              || charName.indexOf("TEXTDECORATION") !== -1
	              || charName.indexOf("CDATA") !== -1
	              || charName.indexOf("FONT") !== -1
	              || charName.indexOf("SPECIAL THANKS") !== -1
	              || charName.indexOf("RELEASE DATE") !== -1
	              || charName.indexOf("RUNNING TIME") !== -1
	              || charName === "INT"
	              || charName === "EXT"
	              || charName === "I"
	              || povMatch !== null
	              || textMatch === null
	              ) && prevLineWasSpace && charName.trim().length > 0 && commaSeparatedCondition) {

	              currentChar = charName;

	              if(typeof characters[charName] === "undefined"){
	                characters[charName] = {
	                  name: charName,
	                  lineIndex: [],
	                  numberOfLines: [],
	                  numberOfWords: [],
	                  scriptLineNumber: []
	                };
	              }

	              prevLineWasCharName = true;
	              isTalking = true;
	              numLines = 0;
	              numWords = 0;
	              dialogueIndex++;

	              //console.log(charName)
	            } else {

	              prevLineWasCharName = false;
	              isTalking = false;
	            }

	          } else {
	            if(prevLineWasCharName || prevLineWasSpace || isTalking ){
	              numLines += Math.ceil(row.length / 80);
	              numWords += row.split(/[\s]+/g).length;
	              //console.log(numWords)
	            }
	          }

	          prevLineWasSpace = false;
	          async.setImmediate(() => { cb3(); });

	        } 
	        
	      }, () => {
	        cb2();
	      });
	    },   
	    done: () => {

				console.log(`${rows.length} lines`)
				console.log(characters)
				console.log(`${Object.keys(characters).length} clean characters`)

				$(".loading-parser").hide();
				$("#character-list-container, #display-container").show();
				drawCharacterList();

				
	    }
	  });
	}

	function drawCharacterList () {
		var characterListHTML = "";

		var sortedCharacterNames = Object.keys(characters).sort();
		async.forEachSeries(sortedCharacterNames, (charName, cb2) => {

			if(typeof characterGenders[charName] === "undefined"){
				
				var gender = "null";

				if(charName.indexOf("MAN") !== -1) { gender = "male" }
				if(charName.indexOf("WOMAN") !== -1) { gender = "female" }
				if(charName.indexOf("MR") !== -1) { gender = "male" }
				if(charName.indexOf("MRS") !== -1) { gender = "female" }
				if(charName.indexOf("MISS") !== -1) { gender = "female" }
				if(charName.indexOf("BOY") !== -1) { gender = "male" }
				if(charName.indexOf("GIRL") !== -1) { gender = "female" }
				if(charName.indexOf("GUY") !== -1) { gender = "male" }
				if(charName.indexOf("MOM") !== -1 || charName.indexOf("MUM") !== -1 || charName.indexOf("MOTHER") !== -1) { gender = "female" }
				if(charName.indexOf("DAD") !== -1 || charName.indexOf("FATHER") !== -1) { gender = "male" }
				if(charName.indexOf("BROTHER") !== -1) { gender = "male" }
				if(charName.indexOf("SISTER") !== -1) { gender = "female" }


				characterGenders[charName] = gender
			}
			if(characters[charName].lineIndex.length > 0){
	  		characterListHTML += (
	  			`<tr>
		    	 	<td>
		    		 	${charName}
		    	 	</td>
		    	 	<td>	
		    	 		<select class='gender-option form-control' data-character-name='${charName}' onChange="changeCharGender(this)">
		    	 			<option value="null"> - </option>
		    	 			<option value="male"> Male </option>
		    	 			<option value="female"> Female </option>
		    	 			<option value="not-character"> Not a Character </option>
		    	 		</select>
		    	 	</td>
		    	 	<td>
		    	 		${d3.sum(characters[charName].numberOfLines)}
		    	 	</td>
		    	 	<td>
		    	 		${d3.sum(characters[charName].numberOfWords)}
		    	 	</td>
		    	 	<td>
		    	 		<button class="btn btn-danger btn-xs delete-char" type="button" onClick="deleteCharRow(this)"> Remove </button>
		    	 	</td>
	    	 	</tr>`
	  		);
	  	}

			async.setImmediate(() => { cb2(); });
		}, () => {

			$("#character-list").html(
				`<table class="table table-condensed table-striped">
	  			<thead>
	  				<tr>
	  					<th> Character </th>
	  					<th> Gender </th>
	  					<th> # Lines </th>
	  					<th> # Words </th>
	  					<th> </th>
	  				</tr>
	  			</thead>
	  			<tbody>
	  				${characterListHTML}
	  			</tbody>
	  		</table>`);

			for(var charName in characterGenders){
				$(`select[data-character-name="${charName}"`).val(characterGenders[charName])
			}

			drawGenderSplit();
		})
			

	}

	function changeCharGender(option) {
		var charName = $(option).data("character-name");
		characterGenders[charName] = $(option).val();
		drawGenderSplit();
	}

	function deleteCharRow(button) {
		$(button).closest("tr").remove();
		drawGenderSplit();
	}

	$(document).ready(() => {
		$("#parse-text").on("click", () => {
			var inputText = ` \n ${$("#script-input").val()} \n \n`;
			parseText(inputText);

		});

		//$("#parse-text").click();

		$("#clear-text").on("click", () => {
			$("#script-input").val("");
			var inputText = $("#script-input").val();
			parseText(inputText);
		
		});

		$("#reset-character-table").on("click", () => {
			drawCharacterList();
		});

		$("#clear-genders").on("click", () => {
			for(var charName in characterGenders){
				characterGenders[charName] = "null";
				$(`select[data-character-name="${charName}"`).val(characterGenders[charName])
			}

			drawGenderSplit()

		});

	});
